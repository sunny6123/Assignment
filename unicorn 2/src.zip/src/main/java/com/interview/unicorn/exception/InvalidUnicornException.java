package com.interview.unicorn.exception;

public class InvalidUnicornException extends RuntimeException{

    public InvalidUnicornException(String message) {
        super(message);
    }
}
